
<script src="https://unpkg.com/vue@3/dist/vue.global.prod.js"></script>

<script src="https://unpkg.com/vue-i18n@9/dist/vue-i18n.global.prod.js"></script>

<script src="/src/i18n/locales/uk.js"></script>
<script src="/src/i18n/locales/en.js"></script>
<script src="/src/i18n/languages.js"></script>

<script src="/public/src/i18n/index.js"></script>

<script src="/frontend/headerComponent.js" type="module"></script>
